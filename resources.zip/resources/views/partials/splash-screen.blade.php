<div id="splash-screen">
    <span></span>
    <span></span>
    <span></span>
</div>